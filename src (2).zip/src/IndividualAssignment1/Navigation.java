package IndividualAssignment1;

public class Navigation extends GameDescription {


    public Navigation(int roomNumber, String location, String rooomDesricption, String n, String e, String s, String w, int nnumber, int enumber, int snumber, int wnumber) {
        super(roomNumber, location, rooomDesricption, n, e, s, w, nnumber, enumber, snumber, wnumber);
    }




    //method





}
