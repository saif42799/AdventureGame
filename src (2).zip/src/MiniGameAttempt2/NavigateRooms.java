//package MiniGameAttempt2;
//
//public class NavigateRooms extends Room{
//
//
//    public String N;
//    public String E;
//    public String S;
//    public String W;
//    public int NCorenum;
//    public int ECorenum;
//    public int SCorenum;
//    public int WCorenum;
//
//    //constructor
//
//    public NavigateRooms(java.lang.String location, java.lang.String roomDescription, int roomLocation,String N, String E, String S, String W, int NCorenum, int ECorenum, int SCorenum, int WCorenum) {
//        super(location, roomDescription, roomLocation);
//
//        this.N = N;
//        this.E = E;
//        this.S = S;
//        this.W = W;
//        this.NCorenum = NCorenum;
//        this.ECorenum = ECorenum;
//        this.SCorenum = SCorenum;
//        this.WCorenum = WCorenum;
//    }
//
//
//
//
////getter and setters
//    public String getN() {
//        return N;
//    }
//
//    public void setN(String n) {
//        N = n;
//    }
//
//    public String getE() {
//        return E;
//    }
//
//    public void setE(String e) {
//        E = e;
//    }
//
//    public String getS() {
//        return S;
//    }
//
//    public void setS(String s) {
//        S = s;
//    }
//
//    public String getW() {
//        return W;
//    }
//
//    public void setW(String w) {
//        W = w;
//    }
//
//    public int getNCorenum() {
//        return NCorenum;
//    }
//
//    public void setNCorenum(int NCorenum) {
//        this.NCorenum = NCorenum;
//    }
//
//    public int getECorenum() {
//        return ECorenum;
//    }
//
//    public void setECorenum(int ECorenum) {
//        this.ECorenum = ECorenum;
//    }
//
//    public int getSCorenum() {
//        return SCorenum;
//    }
//
//    public void setSCorenum(int SCorenum) {
//        this.SCorenum = SCorenum;
//    }
//
//    public int getWCorenum() {
//        return WCorenum;
//    }
//
//    public void setWCorenum(int WCorenum) {
//        this.WCorenum = WCorenum;
//    }
//
//    int temp = 1;
//    int temp2 = 1;
//
//public int compass(String userDirection, int directionalNum){
//
////    NavigateRooms strater = find(temp2);
////    temp = strater.roomNumber;
//
////        if (userDirection.equalsIgnoreCase(N)) {
////
////            temp = setRoomNumber(temp2);
////            temp2 = setNCorenum(getNCorenum());
////            return temp;
////
////        } else if (userDirection.equalsIgnoreCase(E)) {
////
////            temp = setRoomNumber(temp2);
////            temp2 = setECorenum(getECorenum());
////            return temp;
////
////        } else if (userDirection.equalsIgnoreCase(S)) {
////
////            temp = setRoomNumber(temp2);
////            temp2 = setSCorenum(getSCorenum());
////            return temp;
////
////        } else if (userDirection.equalsIgnoreCase(W)) {
////
////            temp = setRoomNumber(temp2);
////            temp2 = setWCorenum(getWCorenum());
////            return temp;
////
////        }
////        else {
////
////        System.out.println("You can not go that way! Try again.");
////        }
//
//
//    return 0;
//}
//
//
//
//
//
//
//
//}
