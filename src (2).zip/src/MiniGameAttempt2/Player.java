//package MiniGameAttempt2;
//
//public class Player extends Room{
//
//    private Room room;
//
//
//    public Player(java.lang.String location, java.lang.String roomDescription, int roomLocation, Room uRoom) {
//        super(location, roomDescription, roomLocation);
//        this.room = uRoom;
//
//
//    }
//
//
//    public void setRoom(Room aRoom) {
//        this.room = aRoom;
//    }
//
//    public Room getRoom() {
//        return this.room;
//    }
//
//    public int updateLocation(int roomLocation, String roomName, String description){
//
//
//
//
//        return 0;
//    }
//
//
//
//    //---1-----------------------------------------------------------------------------------------------------------
//    //This method checks user input
//    public String userDirectionInput(String direction) {
//
//        if (direction.equalsIgnoreCase("N")) {
//            return "North";
//        }
//        else if (direction.equalsIgnoreCase("E")){
//            return "East";
//        }
//        else if (direction.equalsIgnoreCase("S")){
//            return "South";
//        }
//        else if (direction.equalsIgnoreCase("W")){
//            return "West";
//        }
//
//        return null;
//    }
//    //---1-----------------------------------------------------------------------------------------------------------
//
//
//    //---2-----------------------------------------------------------------------------------------------------------
//    public int playerLocation(String userDirection) {
////        int temp = 1;
////        int temp2 = 1;
////
////
////        NavigateRooms starter = find(temp2);
////        temp2 = starter.roomNumber;
////
////
////        int value = getRoomNumber();
////        getLocation();
////        getRoomDescription();
////        value = setRoomNumber(temp2);
////        temp2 = value;
////
////        int playerLocation = value;
////
////        return temp2;
//
//
//        return 0;
//    }
//
//
//
//    //---2-----------------------------------------------------------------------------------------------------------
//
//
//}
