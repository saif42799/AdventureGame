package IndividualAssignment;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class: Game.java
 *
 * @author Saif Shaikh
 * @version 2022 1.3
 * Course : ITEC 3860
 * Spring 2022
 * Written: Feb 27, 2022
 * The adventure program you will create for this assignment and all followed up assignments is entirely
 * data driven. Just like your final project. The program itself doesn’t know the details of the game geography,
 * the objects that are distributed among the various rooms, or even the words used to move from place to place.
 * All such information is supplied in the form of data files, which the program uses to control its own operation.
 * The ultimate goal is if you run the program with different data files, the same program will guide its players
 * through different adventure games.
 */

public class Game {

    static ArrayList<Navigation> list = new ArrayList<>();

    public static void main(String[] args) {


        //---Phase1-------------------------------------------------------------------------------------------------

        GameDescription gameDescrip = null;
        Navigation navi = null;

        //create Room.txt file
        File file = new File("src/IndividualAssignment/Rooms.txt");
        Scanner scanner = null;

        //If file exists then continue
        try {
            scanner = new Scanner(file);
        } catch (Exception e) {
            System.out.println("Invalid File");
            System.exit(0);
        }




        try {
            //Reading file and assigning
            while (scanner.hasNextLine()) {
                //int roomNumber, String location, String rooomDesricption
                int roomNum = scanner.nextInt();
                scanner.nextLine();
                String location = scanner.nextLine();
                String roomDescriptionLine1 = scanner.nextLine();
                String roomDescriptionLine2 = scanner.nextLine();
                String roomDescriptionLine3 = scanner.nextLine();
                String roomDescription = roomDescriptionLine1 + "\n" + roomDescriptionLine2 + "\n" + roomDescriptionLine3;
                scanner.nextLine();

                String N1 = scanner.next();
                String N1num = scanner.next();
                int N1numToInt = Integer.parseInt(N1num);

                String E2 = scanner.next();
                String E2num = scanner.next();
                int E2numToInt = Integer.parseInt(E2num);

                String S3 = scanner.next();
                String S3num = scanner.next();
                int S3numToInt = Integer.parseInt(S3num);

                String W4 = scanner.next();
                String W4num = scanner.next();
                int W4numToInt = Integer.parseInt(W4num);

                scanner.nextLine();

                gameDescrip = new GameDescription(roomNum, location, roomDescription);
                navi = new Navigation(roomNum, location, roomDescription, N1, E2, S3, W4, N1numToInt, E2numToInt, S3numToInt, W4numToInt);

//                list.add((Navigation) gameDescrip);
                list.add(navi);

            }

            //---Phase2-------------------------------------------------------------------------------------------------

            //Asks the player if they want to play or not, made scanner for user input

            Scanner input = new Scanner(System.in);


            System.out.print("Would you like to play Adventure game demo Y/N: ");

            String yesOrNo = input.nextLine();
            System.out.print("\n");

            //This loop will start the game
            while (yesOrNo.equalsIgnoreCase("Y")) {


                //printing the first room (intro)
                GameDescription strater = find(1);
                System.out.println(strater.rooomDesricption);


                boolean valid = false;
                while (!valid) {
                    System.out.println("\n" + "Which direction do you want to go? (N,S,E,W) ");
                    String IDRoom = input.nextLine();

                    Navigation i = (Navigation) findString(IDRoom);

                    i.setRoomNumber(i.temple);
                     i.setRoomNumber(i.temple);
                    if (i != null) {
                        int rex = i.setRoomNumber(i.temple);
                        int placement = (i.playerPosition(IDRoom));


                        if (i.N.equalsIgnoreCase(IDRoom) || i.N.equalsIgnoreCase("N") || i.S.equalsIgnoreCase(IDRoom) || i.S.equalsIgnoreCase("S") || i.E.equalsIgnoreCase(IDRoom) || i.E.equalsIgnoreCase("E") || i.W.equalsIgnoreCase(IDRoom) || i.W.equalsIgnoreCase("W")) {


                            if (placement == 1) {
                                findString(String.valueOf(i.roomNumber));
                                i.roomNumber = 1;
                                i.compass(IDRoom);

                            }
                            else if (placement == 2){
                                i.roomNumber = 2;
                                i.compass(IDRoom);

                            }
                            else if (placement == 3){
                                i.roomNumber = 3;
                                i.compass(IDRoom);

                            }
                            else if (placement == 4){
                                i.roomNumber = 4;
                                i.compass(IDRoom);

                            }else if (placement == 5){
                                i.roomNumber = 5;
                                i.compass(IDRoom);

                            }
                            else if (placement == 6){
                                i.roomNumber = 6;
                                i.compass(IDRoom);

                            }
                            else if (placement == 7){
                                i.roomNumber = 7;
                                i.compass(IDRoom);

                            }
                            else if (placement == 8){
                                i.roomNumber = 8;
                                i.compass(IDRoom);

                            }
                            else {
                                System.out.println("Placement isn't found ");
                            }


                        } else {
                            System.out.println("Wrong");

                        }

                    }

                }

                System.out.print("\n" + "Would you like to play Adventure game demo again Y/N: ");
                yesOrNo = input.next();
            }


            System.out.println("Thank you for playing! Good Bye!");
            System.out.println("________________________________");


            //close.input
            input.close();

        } catch (Exception e) {

            System.out.println("Something went wrong in Main");

        }
        //close scanner
        scanner.close();

    }

    public static GameDescription find(int num) {
        for (GameDescription i : list) {

            if (num == i.roomNumber) {
                return i;
            }

        }
        return null;
    }

    private static Object findString(String direction1) {
        for (Navigation a : list) {

            if (direction1.equalsIgnoreCase(a.N) || direction1.equalsIgnoreCase(a.S) || direction1.equalsIgnoreCase(a.E) || direction1.equalsIgnoreCase(a.W)) {
                return a;

            }

        }
        return null;
    }


}
