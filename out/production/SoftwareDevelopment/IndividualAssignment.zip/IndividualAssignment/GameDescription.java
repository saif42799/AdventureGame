package IndividualAssignment;

public class GameDescription {

    public int roomNumber;
    public String location;
    public String rooomDesricption;



    public GameDescription(int roomNumber, String location, String rooomDesricption) {
        this.roomNumber = roomNumber;
        this.location = location;
        this.rooomDesricption = rooomDesricption;

    }


    //getter and setters

    public int getRoomNumber(int roomNumber) {
        return roomNumber;
    }

    public String getLocation() {
        return location;
    }

    public String getRooomDesricption() {
        return rooomDesricption;
    }

    public int setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
        return roomNumber;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setRooomDesricption(String rooomDesricption) {
        this.rooomDesricption = rooomDesricption;
    }




}
