package IndividualAssignment;

public class Player extends GameDescription{
    public Player(int roomNumber, String location, String rooomDesricption) {
        super(roomNumber, location, rooomDesricption);
    }


    public boolean roomVisited(){

        return true;

    }

//    public boolean playerPosition(int i){
////        int tempPostion;
//        i = roomNumber;
//        if(roomNumber == 1){
//            return true;
//        }
//        else if (roomNumber == 2){
//            return true;
//        }
//        else if (roomNumber == 3){
//            return true;
//        }
//        else if (roomNumber == 4){
//            return true;
//        }
//        else if (roomNumber == 5){
//            return true;
//        }
//        else if (roomNumber == 6){
//            return true;
//        }
//        else if (roomNumber == 7){
//            return true;
//        }
//        else if (roomNumber == 8){
//            return true;
//        }
//        else{
//            return false;
//        }
//
//
//    }

}
