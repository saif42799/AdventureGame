package IndividualAssignment;


import static IndividualAssignment.Game.find;


public class Navigation extends GameDescription {

    public String N;
    public String E;
    public String S;
    public String W;
    public int Nnumber;
    public int Enumber;
    public int Snumber;
    public int Wnumber;

    public Navigation(int roomNumber, String location, String rooomDesricption, String N, String E, String S, String W, int Nnumber, int Enumber, int Snumber, int Wnumber) {
        super(roomNumber, location, rooomDesricption);
        this.N = N;
        this.E = E;
        this.S = S;
        this.W = W;
        this.Nnumber = Nnumber;
        this.Enumber = Enumber;
        this.Snumber = Snumber;
        this.Wnumber = Wnumber;

    }

    @Override
    public int getRoomNumber(int roomNumber) {
        return super.getRoomNumber(roomNumber);
    }

    @Override
    public int setRoomNumber(int roomNumber) {
        super.setRoomNumber(roomNumber);
        return roomNumber;
    }

    //getter and setters

    public String getN() {
        return N;
    }

    public void setN(String n) {
        N = n;
    }

    public String getE() {
        return E;
    }

    public void setE(String e) {
        E = e;
    }

    public String getS() {
        return S;
    }

    public void setS(String s) {
        S = s;
    }

    public String getW() {
        return W;
    }

    public void setW(String w) {
        W = w;
    }

    public int getNnumber() {
        return Nnumber;
    }

    public void setNnumber(int nnumber) {
        Nnumber = nnumber;
    }

    public int getEnumber() {
        return Enumber;
    }

    public void setEnumber(int enumber) {
        Enumber = enumber;
    }

    public int getSnumber() {
        return Snumber;
    }

    public void setSnumber(int snumber) {
        Snumber = snumber;
    }

    public int getWnumber() {
        return Wnumber;
    }

    public void setWnumber(int wnumber) {
        Wnumber = wnumber;
    }



    //method
    public int rottation(int i){
        i = temple;
        temple =roomNumber;
        return i;
    }


    public int playerPosition(String i) {

        int temp1 = Nnumber;
        int temp2 = Snumber;
        int temp3 = Wnumber;
        int temp4 = Enumber;
        if(i.equalsIgnoreCase(N)){
            Nnumber = temp1;
            temp1 = roomNumber;
        }
        else if(i.equalsIgnoreCase(S)){
            Snumber = temp2;
            temp2 = roomNumber;
        }
        else if (i.equalsIgnoreCase(W)){
            Wnumber = temp3;
            temp3 = roomNumber;
        }
        else if (i.equalsIgnoreCase(E)){
            Enumber = temp4;
            temp4 = roomNumber;
        }
        else {
            return temp1;
        }

        return temp1;
    }


    int temple = 0;
    public void compass(String direction) {
        //                      Nnumber
        // N needs to print out N1numToInt = roomNumber
        //---ID1--------------------------------------------------------------------------------

        if (roomNumber == 1) {
            find(1);
            if (N.equalsIgnoreCase(direction) || N.equalsIgnoreCase("N")) {

                System.out.println("You can't go that way!");

            } else if (S.equalsIgnoreCase(direction) || S.equalsIgnoreCase("S")) {

                System.out.println("You can't go that way!");

            } else if (W.equalsIgnoreCase(direction) || W.equalsIgnoreCase("W")) {

                System.out.println("You can't go that way!");

            } else if (E.equalsIgnoreCase(direction) || E.equalsIgnoreCase("E")) {

                GameDescription findTxt = find(Enumber);
                System.out.println(findTxt.rooomDesricption);
                temple = Enumber;


            } else {
                System.out.println("Something went wrong in Nav");
            }


        }

        //---ID5--------------------------------------------------------------------------------

        if (roomNumber == 2) {
            find(2);
            if (N.equalsIgnoreCase(direction) || N.equalsIgnoreCase("N")) {

                GameDescription findTxt = find(Nnumber);
                System.out.println(findTxt.rooomDesricption);
                temple = Nnumber;


            } else if (S.equalsIgnoreCase(direction) || S.equalsIgnoreCase("S")) {

                GameDescription findTxt = find(Snumber);
                System.out.println(findTxt.rooomDesricption);
                temple = Snumber;


            } else if (W.equalsIgnoreCase(direction) || W.equalsIgnoreCase("W")) {

                GameDescription findTxt = find(Wnumber);
                System.out.println(findTxt.rooomDesricption);
                temple = Wnumber;

            } else if (E.equalsIgnoreCase(direction) || E.equalsIgnoreCase("E")) {

                GameDescription findTxt = find(Enumber);
                System.out.println(findTxt.rooomDesricption);
                temple = Enumber;


            } else {
                System.out.println("Something went wrong in Nav");
            }

        }


        //---ID3--------------------------------------------------------------------------------


        if (roomNumber == 3) {
            find(3);
            if (N.equalsIgnoreCase(direction) || N.equalsIgnoreCase("N")) {

                System.out.println("You can't go that way!");

            } else if (S.equalsIgnoreCase(direction) || S.equalsIgnoreCase("S")) {

                GameDescription findTxt = find(Snumber);
                System.out.println(findTxt.rooomDesricption);
                temple = Snumber;


            } else if (W.equalsIgnoreCase(direction) || W.equalsIgnoreCase("W")) {

                System.out.println("You can't go that way!");

            } else if (E.equalsIgnoreCase(direction) || E.equalsIgnoreCase("E")) {

                System.out.println("You can't go that way!");

            } else {
                System.out.println("Something went wrong in Nav");
            }

        }

        //---ID4--------------------------------------------------------------------------------

        if (roomNumber == 4) {
            find(4);
            if (N.equalsIgnoreCase(direction) || N.equalsIgnoreCase("N")) {

                GameDescription findTxt = find(Nnumber);
                System.out.println(findTxt.rooomDesricption);
                temple = Nnumber;



            } else if (S.equalsIgnoreCase(direction) || S.equalsIgnoreCase("S")) {

                System.out.println("You can't go that way!");

            } else if (W.equalsIgnoreCase(direction) || W.equalsIgnoreCase("W")) {

                System.out.println("You can't go that way!");

            } else if (E.equalsIgnoreCase(direction) || E.equalsIgnoreCase("E")) {

                System.out.println("You can't go that way!");

            } else {
                System.out.println("Something went wrong in Nav");
            }
        }

        //---ID5--------------------------------------------------------------------------------

        if (roomNumber == 5) {
            find(5);
            if (N.equalsIgnoreCase(direction) || N.equalsIgnoreCase("N")) {

                GameDescription findTxt = find(Nnumber);
                System.out.println(findTxt.rooomDesricption);
                temple = Nnumber;


            } else if (S.equalsIgnoreCase(direction) || S.equalsIgnoreCase("S")) {

                GameDescription findTxt = find(Snumber);
                System.out.println(findTxt.rooomDesricption);
                temple = Snumber;


            } else if (W.equalsIgnoreCase(direction) || W.equalsIgnoreCase("W")) {

                GameDescription findTxt = find(Wnumber);
                System.out.println(findTxt.rooomDesricption);
                temple = Wnumber;


            } else if (E.equalsIgnoreCase(direction) || E.equalsIgnoreCase("E")) {

                GameDescription findTxt = find(Enumber);
                System.out.println(findTxt.rooomDesricption);
                temple = Enumber;


            } else {
                System.out.println("Something went wrong in Nav");
            }

        }

        //---ID6--------------------------------------------------------------------------------

        if (roomNumber == 6) {
            find(6);
            if (N.equalsIgnoreCase(direction) || N.equalsIgnoreCase("N")) {

                System.out.println("You can't go that way!");

            } else if (S.equalsIgnoreCase(direction) || S.equalsIgnoreCase("S")) {

                GameDescription findTxt = find(Snumber);
                System.out.println(findTxt.rooomDesricption);
                temple = Snumber;


            } else if (W.equalsIgnoreCase(direction) || W.equalsIgnoreCase("W")) {

                System.out.println("You can't go that way!");

            } else if (E.equalsIgnoreCase(direction) || E.equalsIgnoreCase("E")) {

                System.out.println("You can't go that way!");

            } else {
                System.out.println("Something went wrong in Nav");
            }
        }

        //---ID7--------------------------------------------------------------------------------

        if (roomNumber == 7) {
            find(7);
            if (N.equalsIgnoreCase(direction) || N.equalsIgnoreCase("N")) {

                System.out.println("You can't go that way!");

            } else if (S.equalsIgnoreCase(direction) || S.equalsIgnoreCase("S")) {

                GameDescription findTxt = find(Snumber);
                System.out.println(findTxt.rooomDesricption);
                temple = Snumber;

            } else if (W.equalsIgnoreCase(direction) || W.equalsIgnoreCase("W")) {

                System.out.println("You can't go that way!");

            } else if (E.equalsIgnoreCase(direction) || E.equalsIgnoreCase("E")) {

                System.out.println("You can't go that way!");

            } else {
                System.out.println("Something went wrong in Nav");
            }
        }

        //---ID8--------------------------------------------------------------------------------

        if (roomNumber == 8) {
            find(8);
            if (N.equalsIgnoreCase(direction) || N.equalsIgnoreCase("N")) {

                System.out.println("You can't go that way!");

            } else if (S.equalsIgnoreCase(direction) || S.equalsIgnoreCase("S")) {

                System.out.println("You can't go that way!");

            } else if (W.equalsIgnoreCase(direction) || W.equalsIgnoreCase("W")) {

                GameDescription findTxt = find(Wnumber);
                System.out.println(findTxt.rooomDesricption);
                temple = Wnumber;


            } else if (E.equalsIgnoreCase(direction) || E.equalsIgnoreCase("E")) {

                System.out.println("You can't go that way!");

            } else {
                System.out.println("Something went wrong in Nav");
            }
        }
        roomNumber = temple;

    }





}
